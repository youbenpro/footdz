
export interface Post {
  id: string;
  title: string;
  excerpt?: string;
  imageUrl: string;
  category: string;
  date: string;
  author: string;
}

export interface VideoPost {
  id: string;
  title: string;
  thumbnail: string;
  duration: string;
}

export enum Category {
  HOME = 'الرئيسية',
  NATIONAL_TEAM = 'المنتخب الوطني',
  PRO_NEWS = 'أخبار المحترفين',
  LOCAL_LEAGUE = 'البطولة الوطنية',
  MEDIA = 'ميديا'
}
