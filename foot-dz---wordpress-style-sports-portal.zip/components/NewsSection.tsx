
import React from 'react';
import { Post } from '../types';
import { ChevronLeft, ArrowLeft } from 'lucide-react';

interface NewsSectionProps {
  title: string;
  posts: Post[];
  colorClass?: string;
  isMain?: boolean;
}

const NewsSection: React.FC<NewsSectionProps> = ({ title, posts, colorClass = "bg-primary", isMain = false }) => {
  return (
    <section className="mb-12 font-cairo">
      <div className="flex justify-between items-end mb-8">
        <div className="space-y-1">
          <div className={`w-12 h-1.5 ${colorClass} rounded-full`}></div>
          <h2 className="text-2xl font-black text-gray-800 tracking-tight">{title}</h2>
        </div>
        <a href="#" className="flex items-center gap-1.5 text-xs font-bold text-gray-400 hover:text-primary transition-colors">
          عرض جميع المقالات <ArrowLeft size={14} />
        </a>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map((post) => (
          <article key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-wp border border-gray-100/50 group cursor-pointer hover:shadow-wp-hover transition-all duration-300 flex flex-col">
            <div className="relative h-52 overflow-hidden">
              <img 
                src={post.imageUrl} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                alt={post.title} 
              />
              <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm text-primary text-[10px] px-3 py-1 rounded-full font-black shadow-sm">
                {post.category}
              </div>
              <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-all"></div>
            </div>
            <div className="p-6 flex flex-col flex-1">
              <div className="flex items-center gap-2 mb-3">
                 <span className="text-[10px] text-gray-400 font-bold">{post.date}</span>
                 <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
                 <span className="text-[10px] text-gray-400 font-bold">{post.author}</span>
              </div>
              <h3 className="text-lg font-extrabold text-gray-800 leading-snug group-hover:text-primary transition-colors mb-3 line-clamp-2">
                {post.title}
              </h3>
              <p className="text-gray-500 text-xs leading-relaxed line-clamp-2 mb-6">
                {post.excerpt || "تفاصيل أوفى عن هذا الخبر الرياضي الحصري تجدونها في المقال الكامل عبر موقعنا..."}
              </p>
              <div className="mt-auto pt-4 border-t border-gray-50 flex justify-between items-center">
                 <span className="text-[11px] font-black text-primary group-hover:underline underline-offset-4 decoration-2">اقرأ المزيد</span>
                 <ChevronLeft size={16} className="text-primary translate-x-1 group-hover:translate-x-0 transition-transform" />
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};

export default NewsSection;
