
import React from 'react';
import { VideoPost } from '../types';
import { Play, Tv } from 'lucide-react';

interface VideoSectionProps {
  videos: VideoPost[];
}

const VideoSection: React.FC<VideoSectionProps> = ({ videos }) => {
  return (
    <section className="bg-slate-950 py-16 text-white font-cairo my-16 rounded-[2rem] overflow-hidden shadow-2xl relative">
      {/* Decorative Blur */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
      
      <div className="container mx-auto px-10 relative z-10">
        <div className="flex items-center justify-between mb-12 border-b border-white/10 pb-6">
          <div className="flex items-center gap-4">
            <div className="bg-accent-gold text-black p-3 rounded-2xl rotate-3">
               <Tv size={28} />
            </div>
            <div>
              <h2 className="text-3xl font-black tracking-tight">ميديا <span className="text-accent-gold italic">DZ</span></h2>
              <p className="text-white/40 text-xs font-bold mt-1 uppercase tracking-widest">Digital Content & Highlights</p>
            </div>
          </div>
          <button className="text-xs font-bold bg-white/5 hover:bg-white/10 px-6 py-2.5 rounded-full border border-white/10 transition-all">مشاهدة الكل</button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {videos.map((v) => (
            <div key={v.id} className="group cursor-pointer">
              <div className="relative aspect-video rounded-2xl overflow-hidden border border-white/5 bg-slate-900 ring-4 ring-transparent group-hover:ring-primary/40 transition-all duration-300">
                <img 
                  src={v.thumbnail} 
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity duration-500 group-hover:scale-105" 
                  alt={v.title}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="bg-white/10 backdrop-blur-md p-4 rounded-full border border-white/20 transform scale-90 group-hover:scale-100 group-hover:bg-primary transition-all duration-300">
                      <Play fill="white" size={24} className="text-white ml-1" />
                   </div>
                </div>
                <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded-md font-bold border border-white/10">
                  {v.duration}
                </div>
                <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-t from-slate-950/80 to-transparent"></div>
              </div>
              <h3 className="mt-4 text-base font-bold text-gray-200 group-hover:text-accent-gold transition-colors line-clamp-2 leading-relaxed px-1">
                {v.title}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default VideoSection;
