
import React from 'react';
import { Post } from '../types';
import { Clock, User } from 'lucide-react';

interface HeroProps {
  featured: Post;
  sidebarPosts: Post[];
}

const Hero: React.FC<HeroProps> = ({ featured, sidebarPosts }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 my-8 font-cairo">
      {/* Main Featured */}
      <div className="lg:col-span-8 relative h-[350px] md:h-[500px] overflow-hidden rounded-2xl shadow-wp group cursor-pointer">
        <img 
          src={featured.imageUrl} 
          alt={featured.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
        <div className="absolute bottom-0 right-0 left-0 p-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-primary text-white text-[10px] font-extrabold px-3 py-1 rounded uppercase tracking-wider">
              {featured.category}
            </span>
            <div className="flex items-center gap-1.5 text-[10px] text-white/80 font-medium">
              <Clock size={12} />
              <span>منذ ساعتين</span>
            </div>
          </div>
          <h1 className="text-2xl md:text-4xl font-black leading-[1.2] mb-4 group-hover:text-accent-gold transition-colors">
            {featured.title}
          </h1>
          <p className="text-gray-300 text-sm md:text-base hidden md:block line-clamp-2 max-w-2xl font-medium leading-relaxed">
            {featured.excerpt}
          </p>
        </div>
      </div>

      {/* Sidebar Top Stories */}
      <div className="lg:col-span-4 flex flex-col h-full">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-wp flex-1 overflow-hidden flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-black text-gray-800 relative after:content-[''] after:absolute after:-bottom-1 after:right-0 after:w-8 after:h-1 after:bg-primary rounded-full">
              الأكثر تداولاً
            </h2>
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse"></div>
              <div className="w-1.5 h-1.5 bg-primary/40 rounded-full"></div>
            </div>
          </div>
          
          <div className="space-y-5 custom-scrollbar overflow-y-auto flex-1 pr-1">
            {sidebarPosts.map((post, idx) => (
              <div key={post.id} className="group cursor-pointer flex gap-4 transition-all">
                <div className="relative flex-shrink-0 w-24 h-16 overflow-hidden rounded-lg">
                  <img src={post.imageUrl} className="w-full h-full object-cover transition-transform group-hover:scale-110" alt={post.title} />
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent"></div>
                </div>
                <div className="flex flex-col justify-between py-0.5">
                  <h3 className="text-xs font-bold text-gray-800 leading-normal group-hover:text-primary transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] text-accent font-black">{post.category}</span>
                    <span className="text-[9px] text-gray-400">• {post.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <button className="mt-6 w-full py-3 bg-gray-50 text-gray-600 text-xs font-bold rounded-xl hover:bg-primary hover:text-white transition-all">
            استكشاف المزيد من الأخبار
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
