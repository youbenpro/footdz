
import React, { useState, useEffect } from 'react';
import { Category } from '../types';
import { Search, Menu, X, Calendar, Globe, Bell } from 'lucide-react';

interface HeaderProps {
  activeCategory: Category;
  setActiveCategory: (cat: Category) => void;
}

const Header: React.FC<HeaderProps> = ({ activeCategory, setActiveCategory }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    setCurrentDate(new Intl.DateTimeFormat('ar-DZ', options).format(new Date()));

    const handleScroll = () => setIsScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = Object.values(Category);

  return (
    <header className="w-full font-cairo z-[60]">
      {/* Top Bar */}
      <div className="bg-primary-dark text-white/90 py-1.5 hidden md:block">
        <div className="container mx-auto px-4 flex justify-between items-center text-[11px] font-medium">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 border-l border-white/20 pl-4">
              <Calendar size={12} className="text-accent-gold" />
              <span>{currentDate}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Globe size={12} className="text-accent-gold" />
              <span>الجزائر العاصمة</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-accent-gold transition-colors">عاجل</a>
            <a href="#" className="hover:text-accent-gold transition-colors">اتصل بنا</a>
            <div className="flex gap-2 mr-4 border-r border-white/20 pr-4">
              <div className="w-5 h-5 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent-gold cursor-pointer transition-all">f</div>
              <div className="w-5 h-5 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent-gold cursor-pointer transition-all">t</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Nav Container */}
      <div className={`transition-all duration-300 ${isScrolled ? 'fixed top-0 left-0 right-0 shadow-xl bg-white/95 backdrop-blur-md py-2' : 'bg-white py-4 border-b border-gray-100'}`}>
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-12">
            {/* Logo */}
            <a 
              href="/" 
              onClick={(e) => { e.preventDefault(); setActiveCategory(Category.HOME); }}
              className="group flex items-center"
            >
              <div className="text-3xl font-black tracking-tight flex items-baseline">
                <span className="text-primary group-hover:text-primary-light transition-colors">FOOT</span>
                <span className="text-accent-gold px-1 bg-gray-50 rounded mx-0.5 group-hover:bg-accent-gold group-hover:text-white transition-all">DZ</span>
              </div>
            </a>

            {/* Desktop Menu */}
            <ul className="hidden lg:flex items-center gap-1">
              {menuItems.map((item) => (
                <li key={item}>
                  <button
                    onClick={() => setActiveCategory(item)}
                    className={`px-4 py-2 rounded-full font-bold text-sm transition-all relative ${
                      activeCategory === item 
                        ? 'bg-primary text-white shadow-md' 
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>

            {/* Search & Mobile */}
            <div className="flex items-center gap-3">
              <button className="p-2 text-gray-500 hover:text-primary hover:bg-gray-100 rounded-full transition-all">
                <Search size={20} />
              </button>
              <button className="hidden md:flex items-center gap-2 bg-accent/5 text-accent px-4 py-2 rounded-full font-bold text-xs hover:bg-accent hover:text-white transition-all">
                <Bell size={14} />
                <span>مباشر</span>
              </button>
              <button 
                className="lg:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-full"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Breaking News Ticker */}
      {!isScrolled && (
        <div className="bg-gray-50 border-b border-gray-100 overflow-hidden py-1.5 hidden md:block">
          <div className="container mx-auto px-4 flex items-center">
            <div className="bg-accent text-white text-[10px] font-black px-3 py-1 rounded-sm ml-4 whitespace-nowrap shadow-sm">عاجل</div>
            <div className="flex-1 overflow-hidden">
              <p className="animate-marquee whitespace-nowrap text-xs text-gray-600 font-bold">
                • انطلاق معسكر المنتخب الوطني بمركز سيدي موسى بحضور جميع الركائز • الفيفا تختار ملعب حسين آيت أحمد ضمن أجمل الملاعب العالمية • رياض محرز يقود ناديه للفوز في الدوري السعودي بتمريرة حاسمة رائعة • ترقب كبير لتشكيلة الخضر لمباراة الغد
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-[70] bg-black/50 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}>
          <div className="bg-white w-[80%] h-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-8 pb-4 border-b">
              <span className="text-2xl font-black text-primary">FOOT<span className="text-accent-gold">DZ</span></span>
              <button onClick={() => setIsMenuOpen(false)}><X size={24} /></button>
            </div>
            <ul className="space-y-2">
              {menuItems.map((item) => (
                <li key={item}>
                  <button
                    onClick={() => { setActiveCategory(item); setIsMenuOpen(false); }}
                    className={`w-full text-right px-4 py-3 rounded-lg font-bold text-base transition-all ${
                      activeCategory === item ? 'bg-primary text-white shadow-lg' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
