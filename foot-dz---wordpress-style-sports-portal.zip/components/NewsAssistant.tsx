
import React, { useState, useRef, useEffect } from 'react';
import { askFootballAssistant } from '../services/geminiService';
// Added ChevronLeft to the lucide-react import list
import { Bot, Send, Loader2, X, ExternalLink, Sparkles, MessageSquare, ChevronLeft } from 'lucide-react';

const NewsAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<{ text: string; links: any[] } | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [response, loading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResponse(null);
    try {
      const res = await askFootballAssistant(query);
      setResponse(res);
    } catch (err) {
      setResponse({ text: "عذراً، حدث خطأ ما. يرجى المحاولة لاحقاً.", links: [] });
    } finally {
      setLoading(false);
      setQuery('');
    }
  };

  return (
    <div className="fixed bottom-8 left-8 z-[100] font-cairo">
      {isOpen ? (
        <div className="bg-white w-[380px] md:w-[420px] h-[550px] shadow-[0_20px_50px_rgba(0,0,0,0.15)] rounded-3xl border border-gray-100 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-primary p-5 text-white flex justify-between items-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
            <div className="flex items-center gap-3 z-10">
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                <Bot size={22} className="text-accent-gold" />
              </div>
              <div>
                <span className="font-black text-sm block">مساعد FOOT DZ</span>
                <span className="text-[10px] text-white/60 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span> متصل الآن
                </span>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="z-10 bg-white/10 p-2 rounded-full hover:bg-white/20 transition-all"
            >
              <X size={18} />
            </button>
          </div>

          {/* Chat Area */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5 bg-gray-50 custom-scrollbar">
            {!response && !loading && (
              <div className="text-center py-10">
                <div className="bg-primary/5 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6">
                  <Sparkles size={32} className="text-primary" />
                </div>
                <h3 className="font-black text-gray-800 mb-2">كيف يمكنني مساعدتك؟</h3>
                <p className="text-xs text-gray-400 px-10 leading-relaxed font-bold">
                  اسألني عن نتائج "الخضر"، أخبار محرز، ترتيب الرابطة الأولى أو أي معلومة رياضية جزائرية.
                </p>
                <div className="mt-8 flex flex-wrap justify-center gap-2 px-4">
                  {['نتائج المنتخب الوطني', 'أهداف محرز اليوم', 'ترتيب الدوري'].map(q => (
                    <button 
                      key={q} 
                      onClick={() => { setQuery(q); }} 
                      className="text-[10px] font-bold px-3 py-1.5 bg-white rounded-full border border-gray-100 shadow-sm hover:border-primary hover:text-primary transition-all"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white p-4 rounded-2xl rounded-tr-none shadow-sm border border-gray-100 flex items-center gap-3">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce"></div>
                  </div>
                  <span className="text-xs font-bold text-gray-400">جاري معالجة طلبك...</span>
                </div>
              </div>
            )}

            {response && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="bg-primary text-white p-4 rounded-2xl rounded-tl-none shadow-md text-sm leading-relaxed text-right relative">
                   <div className="absolute -top-2 left-0 text-primary opacity-20"><Bot size={32} /></div>
                  {response.text}
                </div>
                
                {response.links.length > 0 && (
                  <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                    <p className="text-[10px] text-gray-400 mb-3 font-black flex items-center gap-1">
                      <ExternalLink size={10} /> مصادر موثوقة للخبر:
                    </p>
                    <div className="flex flex-col gap-2">
                      {response.links.slice(0, 3).map((link, i) => (
                        <a 
                          key={i} 
                          href={link.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[11px] font-bold text-gray-600 hover:text-primary p-2 bg-gray-50 rounded-lg border border-transparent hover:border-primary/20 transition-all flex items-center justify-between"
                        >
                          <span className="line-clamp-1">{link.title}</span>
                          <ChevronLeft size={12} className="flex-shrink-0" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSubmit} className="p-4 bg-white border-t border-gray-50">
            <div className="relative group">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="اكتب سؤالك هنا..."
                className="w-full bg-gray-50 rounded-2xl pl-12 pr-6 py-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:bg-white transition-all border border-transparent group-focus-within:border-primary/30"
              />
              <button 
                type="submit" 
                disabled={loading || !query.trim()}
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-primary text-white p-2.5 rounded-xl hover:bg-primary-dark transition-all disabled:opacity-30 shadow-lg disabled:shadow-none"
              >
                <Send size={18} />
              </button>
            </div>
            <p className="text-[9px] text-gray-300 text-center mt-3 font-bold">مدعوم بتقنية الذكاء الاصطناعي من Google Gemini</p>
          </form>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="group bg-primary text-white p-4 rounded-3xl shadow-[0_15px_30px_rgba(0,98,51,0.3)] hover:shadow-[0_20px_40px_rgba(0,98,51,0.4)] transition-all transform hover:scale-110 flex items-center gap-3"
        >
          <div className="flex flex-col items-end mr-1 overflow-hidden max-w-0 group-hover:max-w-[150px] transition-all duration-500 whitespace-nowrap">
             <span className="text-[10px] font-black opacity-60 uppercase tracking-tighter">AI Assistant</span>
             <span className="font-black text-sm">اسأل مساعدنا الذكي</span>
          </div>
          <div className="relative">
             <MessageSquare size={26} className="text-white" />
             <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent border-2 border-primary rounded-full"></span>
          </div>
        </button>
      )}
    </div>
  );
};

export default NewsAssistant;
