
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import NewsSection from './components/NewsSection';
import VideoSection from './components/VideoSection';
import NewsAssistant from './components/NewsAssistant';
import { Category } from './types';
import { MOCK_POSTS, MOCK_VIDEOS } from './constants';

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<Category>(Category.HOME);

  // Scroll to top on category change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeCategory]);

  const filteredPosts = activeCategory === Category.HOME 
    ? MOCK_POSTS 
    : MOCK_POSTS.filter(p => p.category === activeCategory);

  const nationalTeamPosts = MOCK_POSTS.filter(p => p.category === Category.NATIONAL_TEAM);
  const proNewsPosts = MOCK_POSTS.filter(p => p.category === Category.PRO_NEWS);

  return (
    <div className="min-h-screen flex flex-col font-cairo bg-surface-bg selection:bg-primary/20 selection:text-primary">
      <Header activeCategory={activeCategory} setActiveCategory={setActiveCategory} />

      <main className="flex-grow container mx-auto px-4 pb-20">
        {activeCategory === Category.HOME && (
          <div className="animate-in fade-in duration-700">
            <Hero 
              featured={MOCK_POSTS[0]} 
              sidebarPosts={MOCK_POSTS.slice(1, 6)} 
            />

            <div className="grid grid-cols-1 gap-12 mt-12">
              <NewsSection 
                title="أخبار المنتخب الوطني" 
                posts={nationalTeamPosts.slice(0, 3)} 
                colorClass="bg-primary"
                isMain
              />

              <VideoSection videos={MOCK_VIDEOS} />

              <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-wp">
                 <NewsSection 
                    title="أخبار المحترفين الجزائريين" 
                    posts={proNewsPosts.slice(0, 6)} 
                    colorClass="bg-accent-gold"
                  />
              </div>
            </div>
          </div>
        )}

        {activeCategory !== Category.HOME && (
          <div className="mt-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
             <div className="bg-white p-10 rounded-[2.5rem] shadow-wp mb-12 border-b-8 border-primary relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full bg-primary/5 -z-10"></div>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h1 className="text-4xl font-black text-gray-900 tracking-tight">{activeCategory}</h1>
                    <p className="text-gray-500 mt-3 font-bold text-lg">كل ما تحتاج معرفته عن {activeCategory} الجزائرية بلحظة بلحظة</p>
                  </div>
                  <div className="flex -space-x-3 overflow-hidden rtl:space-x-reverse">
                    {[1,2,3,4].map(i => (
                      <img key={i} className="inline-block h-12 w-12 rounded-full ring-4 ring-white" src={`https://picsum.photos/seed/user${i}/100/100`} alt="Contributor" />
                    ))}
                    <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary text-white text-xs font-bold ring-4 ring-white">10+</div>
                  </div>
                </div>
             </div>
             
             <NewsSection 
                title={`أحدث التغطيات في ${activeCategory}`} 
                posts={filteredPosts} 
                colorClass={activeCategory === Category.NATIONAL_TEAM ? "bg-primary" : "bg-primary-light"}
              />
          </div>
        )}
      </main>

      {/* Modern Footer */}
      <footer className="bg-slate-900 text-white py-20 border-t-[6px] border-accent-gold">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <a href="/" className="text-4xl font-black text-white flex items-center gap-1 group">
                <span className="text-primary group-hover:text-primary-light transition-colors">FOOT</span>
                <span className="text-accent-gold italic">DZ</span>
              </a>
              <p className="text-slate-400 text-sm leading-relaxed font-bold">
                البوابة الرياضية الأولى في الجزائر المتخصصة في شؤون كرة القدم المحلية والعالمية. تغطية حصرية لمركز سيدي موسى ومباريات الخضر.
              </p>
            </div>
            
            <div className="space-y-6">
              <h4 className="text-lg font-black relative after:content-[''] after:absolute after:-bottom-2 after:right-0 after:w-8 after:h-1 after:bg-primary">روابط سريعة</h4>
              <ul className="space-y-3 text-slate-400 text-sm font-bold">
                <li><a href="#" className="hover:text-accent-gold transition-colors">عن الموقع</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">فريق التحرير</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">أعلن معنا</a></li>
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-black relative after:content-[''] after:absolute after:-bottom-2 after:right-0 after:w-8 after:h-1 after:bg-primary">الأقسام الأكثر متابعة</h4>
              <ul className="space-y-3 text-slate-400 text-sm font-bold">
                <li><a href="#" className="hover:text-accent-gold transition-colors">مباريات المنتخب الوطني</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">انتقالات اللاعبين</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">الرابطة المحترفة الأولى</a></li>
                <li><a href="#" className="hover:text-accent-gold transition-colors">تحليلات تقنية</a></li>
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-black relative after:content-[''] after:absolute after:-bottom-2 after:right-0 after:w-8 after:h-1 after:bg-primary">النشرة الإخبارية</h4>
              <p className="text-slate-400 text-xs font-bold leading-relaxed">كن أول من يعلم بآخر أخبار المنتخب الوطني الجزائري عبر بريدك الإلكتروني.</p>
              <div className="flex">
                <input type="email" placeholder="بريدك الإلكتروني" className="bg-slate-800 border-none rounded-r-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary w-full" />
                <button className="bg-primary hover:bg-primary-light px-4 py-3 rounded-l-xl transition-colors font-black text-xs">اشترك</button>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-slate-500 text-xs font-black uppercase tracking-widest">
              © 2026 FOOT DZ PORTAL - THE ULTIMATE ALGERIAN FOOTBALL SOURCE
            </p>
            <div className="flex gap-6 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all">
               <img src="https://upload.wikimedia.org/wikipedia/commons/7/77/Flag_of_Algeria.svg" className="h-4 w-auto rounded-sm" alt="Algeria" />
            </div>
          </div>
        </div>
      </footer>

      <NewsAssistant />
    </div>
  );
};

export default App;
