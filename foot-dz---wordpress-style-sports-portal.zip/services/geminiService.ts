
import { GoogleGenAI } from "@google/genai";

export const askFootballAssistant = async (query: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a professional Algerian football analyst. Answer the following user question in Arabic: ${query}. Focus on recent news, scores, and transfers.`,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
      },
    });

    const text = response.text || "عذراً، لا يمكنني الحصول على المعلومات المطلوبة حالياً.";
    const links = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "رابط خارجي",
      url: chunk.web?.uri
    })).filter((l: any) => l.url) || [];

    return { text, links };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
