
import { Post, VideoPost, Category } from './types';

export const COLORS = {
  primary: '#042f2a',
  accent: '#D1B200',
  newsBlue: '#1c5ba3',
};

export const MOCK_POSTS: Post[] = [
  {
    id: '1',
    title: 'المنتخب الوطني يستعد للمباراة القادمة بتشكيلة مفاجئة وقوية',
    excerpt: 'بدأ الناخب الوطني في وضع اللمسات الأخيرة على التشكيلة الأساسية التي ستواجه المنتخب المنافس في الجولة القادمة...',
    imageUrl: 'https://picsum.photos/seed/foot1/800/450',
    category: Category.NATIONAL_TEAM,
    date: '17 جانفي 2026',
    author: 'أحمد بن علي'
  },
  {
    id: '2',
    title: 'شاهد أهداف محرز اليوم مع ناديه في الدوري السعودي',
    excerpt: 'واصل النجم الجزائري رياض محرز تألقه الكبير مسجلاً هدفاً رائعاً وصناعة آخر في مباراة فريقه الأخيرة...',
    imageUrl: 'https://picsum.photos/seed/foot2/400/300',
    category: Category.PRO_NEWS,
    date: '16 جانفي 2026',
    author: 'ياسين براهيمي'
  },
  {
    id: '3',
    title: 'البطولة الوطنية: صراع الصدارة يشتعل بعد تعثر المتصدر',
    excerpt: 'شهدت الجولة الأخيرة من الرابطة المحترفة الأولى نتائج غير متوقعة قلبت موازين الترتيب العام...',
    imageUrl: 'https://picsum.photos/seed/foot3/400/300',
    category: Category.LOCAL_LEAGUE,
    date: '15 جانفي 2026',
    author: 'كمال فوزي'
  },
  {
    id: '4',
    title: 'موهبة شابة من أصول جزائرية تقترب من التوقيع لنادي ميلان',
    imageUrl: 'https://picsum.photos/seed/foot4/400/300',
    category: Category.PRO_NEWS,
    date: '15 جانفي 2026',
    author: 'سمير عبود'
  },
  {
    id: '5',
    title: 'تصريحات قوية للمدرب الوطني حول استبعاد بعض الأسماء',
    imageUrl: 'https://picsum.photos/seed/foot5/400/300',
    category: Category.NATIONAL_TEAM,
    date: '14 جانفي 2026',
    author: 'أحمد بن علي'
  },
  {
    id: '6',
    title: 'تطورات قضية الملاعب الجديدة وجاهزيتها للموسم القادم',
    imageUrl: 'https://picsum.photos/seed/foot6/400/300',
    category: Category.LOCAL_LEAGUE,
    date: '13 جانفي 2026',
    author: 'سعيد حمزة'
  }
];

export const MOCK_VIDEOS: VideoPost[] = [
  { id: 'v1', title: 'ملخص مباراة الخضر الأخيرة', thumbnail: 'https://picsum.photos/seed/v1/300/180', duration: '05:20' },
  { id: 'v2', title: 'كواليس تدريبات المنتخب بمركز سيدي موسى', thumbnail: 'https://picsum.photos/seed/v2/300/180', duration: '08:45' },
  { id: 'v3', title: 'أفضل 10 أهداف جزائرية في أوروبا هذا الأسبوع', thumbnail: 'https://picsum.photos/seed/v3/300/180', duration: '03:15' },
  { id: 'v4', title: 'لقاء خاص مع أسطورة الكرة الجزائرية', thumbnail: 'https://picsum.photos/seed/v4/300/180', duration: '12:30' },
];
